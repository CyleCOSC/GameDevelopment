
public class flyFly extends pokerEnemy{

    public flyFly(int centerX,int centerY){
        setCenterX(centerX);
        setCenterY(centerY);
    }
}