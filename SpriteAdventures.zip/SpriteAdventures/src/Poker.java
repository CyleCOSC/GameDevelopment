
public class Poker extends pokerEnemy {

	public Poker(int centerX,int centerY){
        setCenterX(centerX);
        setCenterY(centerY);
	}

}