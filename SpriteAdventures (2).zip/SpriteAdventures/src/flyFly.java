
public class flyFly extends Enemy{

    public flyFly(int centerX,int centerY){
        setCenterX(centerX);
        setCenterY(centerY);
    }
}